#include "mainclass.h"
#include "../files/fontrenderer.h"

void MainClass::tick(int timePassedMS) {
	float timePassedS = timePassedMS/1000;
	getEvents();
	SDL_SetRenderDrawColor( RENDERER, 0, 0, 0, 0 );
	SDL_RenderClear(RENDERER);
	int size = particles.size();
	std::cout << "you have " << size << " particles" << std::endl;
	for (int i = 0; i < size; i++) {
		while (!particles[i].active) {
			particles.erase(particles.begin()+i);
			i++;
		}
		particles[i].calc();
		particles[i].render();
	}
	if (!pause) {
			rect.x = boxX.getPoint()-40;
			rect.y = boxY.getPoint()-40;
			rect.w = 80;
			rect.h = 80;
			//cout << "boxX:" << boxX.getPoint();
			SDL_SetRenderDrawColor(RENDERER, 255, 255, 255, 255);
			SDL_RenderFillRect(RENDERER, &rect);
	}
	else {
		handleMenu();
	}
	color.r = 255;
	color.g = 255;
	color.b = 255;
	steelfish30.renderDynamicText( averageFPS, 300, color, RENDERER, windowW-120, 20 );
	SDL_RenderPresent( RENDERER );
}