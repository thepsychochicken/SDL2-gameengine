#ifndef _MOUSE_
	#define _MOUSE_

	class Mouse {
		public:
			int x,y;
			bool right,left;
			Mouse();
	};

#endif