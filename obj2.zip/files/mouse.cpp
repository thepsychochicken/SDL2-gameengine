#include "mouse.h"

Mouse::Mouse() {
	x = 0;
	y = 0;
	left = false;
	right = false;
}